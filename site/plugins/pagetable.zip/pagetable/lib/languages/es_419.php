<?php

return array(
    'pagetable.rowsPerPage'  => 'Página mostradas',
    'pagetable.of'           => 'de',
    'pagetable.all'          => 'Todas',
    'pagetable.filter-pages' => 'Filtrar páginas…',
    'pagetable.reset'        => 'Restablecer',
    'pagetable.loading'      => 'Cargando paginas…',
);
