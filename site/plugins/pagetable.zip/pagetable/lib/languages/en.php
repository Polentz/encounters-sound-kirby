<?php

return array(
    'pagetable.rowsPerPage'  => 'Pages displayed',
    'pagetable.of'           => 'of',
    'pagetable.all'          => 'All',
    'pagetable.filter-pages' => 'Filter pages…',
    'pagetable.reset'        => 'Reset',
    'pagetable.loading'      => 'Loading pages…',
);
