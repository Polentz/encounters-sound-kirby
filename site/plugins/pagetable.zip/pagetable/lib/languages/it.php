<?php

return array(
	'pagetable.rowsPerPage'  => 'Pagine visualizzate',
	'pagetable.of'           => 'di',
	'pagetable.all'          => 'Tutte',
	'pagetable.filter-pages' => 'Filtra le pagine…',
	'pagetable.reset'        => 'Rimuovi filtro',
    'pagetable.loading'      => 'Caricamento pagina…',
);
