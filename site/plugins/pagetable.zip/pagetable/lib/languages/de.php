<?php

return array(
	'pagetable.rowsPerPage'  => 'Anzuzeigende Seiten',
	'pagetable.of'           => 'von',
	'pagetable.all'          => 'Alle',
	'pagetable.filter-pages' => 'Seiten filtern…',
	'pagetable.reset'        => 'Zurücksetzen',
    'pagetable.loading'      => 'Seiten laden…',
);
