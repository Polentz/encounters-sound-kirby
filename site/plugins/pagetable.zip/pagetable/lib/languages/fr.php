<?php

return array(
    'pagetable.rowsPerPage'  => 'Pages affichées',
    'pagetable.of'           => 'sur',
    'pagetable.all'          => 'Toutes',
    'pagetable.filter-pages' => 'Filtrer les pages…',
    'pagetable.reset'        => 'Réinitialiser',
    'pagetable.loading'      => 'Chargement des pages…',
);
